MOCK_DATA:
This dataset used for employee data. It is a synthetic dataset.


SupplyChainAnalysisDataset:
This dataset used for sales, order, shipping and inventory process.
Link for this dataset: https://www.kaggle.com/datasets/shashwatwork/dataco-smart-supply-chain-for-big-data-analysis


SupplyChainAnalysisDataset_Description:
This csv is description of SupplyChainAnalysisDataset's columns.


SupplyChainAnalysisDatasetWithEmpNo:
This csv is SupplyChainAnalysisDataset with EmpNo.
